<?php

namespace App\Http\Controllers;

use App\Models\EmailSubscription;
use Illuminate\Http\Request;

class EmailSubscriptionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\EmailSubscription  $emailSubscription
     * @return \Illuminate\Http\Response
     */
    public function show(EmailSubscription $emailSubscription)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\EmailSubscription  $emailSubscription
     * @return \Illuminate\Http\Response
     */
    public function edit(EmailSubscription $emailSubscription)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\EmailSubscription  $emailSubscription
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, EmailSubscription $emailSubscription)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\EmailSubscription  $emailSubscription
     * @return \Illuminate\Http\Response
     */
    public function destroy(EmailSubscription $emailSubscription)
    {
        //
    }
}
